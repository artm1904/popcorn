#pragma once

#include "../Ball/Ball.h"
#include <windef.h>

enum EPlatform_State {
  EPS_Missing,
  EPS_Ready,
  EPS_Normal,
  EPS_Meltdown,
  EPS_Roll_In,
  EPS_Expand_Rall_In
};

class AsPlatform : public AHit_Checker {

public:
  AsPlatform();
  bool Check_Hit(double next_x_pos, double next_y_pos, ABall *ball) override;

  void Draw(HDC hdc, RECT &paint_area);
  void Init();
  void Act();

  EPlatform_State Get_State();
  void Set_State(EPlatform_State new_state);
  void Redraw_Platorm();

  int Platform_X_Step;
  int X_Pos;
  int Width;
  int Inner_width;
  int Rolling_Step;

private:
  void Draw_Circle_Hilight(HDC hdc, int x, int y);
  void Clear_BG(HDC hdc);
  void Draw_Normal_State(HDC hdc, RECT &paint_area);
  void Draw_Meltdown_State(HDC hdc, RECT &paint_area);
  void Draw_Roll_In_State(HDC hdc, RECT &paint_area);
  void Draw_Expanding_Rall_In_State(HDC hdc, RECT &paint_area);
  static const int Normal_Width = 28;
  int Meltdown_Platform_Y_Pos[Normal_Width * AsConfig::GLOBAL_SCALE];

  EPlatform_State Platform_State;
  static const int HEIGHT = 7;
  static const int CIRCLE_RADIUS = 7;
  static const int Meltdown_Speed = 3;
  static const int ROLL_IN_PLATFORM_X_POS = 99;
  static constexpr double MAX_ROLLING_STEP = 16.0;
  static constexpr double ROLLING_PLATFORM_SPEED = 3.0;
  static constexpr double Normal_Platform_Inner_Width =
      Normal_Width - CIRCLE_RADIUS;
  RECT Platform_Rect, Prev_Platform_Rect;
  HPEN Platforn_Circle_Pen, Platform_Inner_Pen;
  HBRUSH Platform_Circle_Brush, Platform_Inner_Brush;
  HPEN While_Hightlight_Platform;
};
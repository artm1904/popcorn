#pragma once

#include "../Ball/Ball.h"
#include "Active_Brick.h"

enum ELetter_Type { ELT_None, ELT_O };

class ALevel : public AHit_Checker {

public:
  ALevel();
  bool Check_Hit(double next_x_pos, double next_y_pos, ABall *ball) override;

  void Init();
  void Ser_Current_Level (char level[AsConfig::LEVEL_HEIGHT][AsConfig::LEVEL_WIDTH]);
  void Draw(HDC hdc, RECT &paint_area);

  AActive_Brick Active_Brick;
  static char Level_01[AsConfig::LEVEL_HEIGHT][AsConfig::LEVEL_WIDTH];
  static char Test_Level_01[AsConfig::LEVEL_HEIGHT][AsConfig::LEVEL_WIDTH];

private:
  bool Is_Check_Horizontal_First(double next_x_pos, double next_y_pos);
  bool Check_Vertical_Hit(double next_x_pos, double next_y_pos, int level_x,
                          int level_y, ABall *ball, double &reflection_pos );

  bool Check_Horizontal_Hit(double next_x_pos, double next_y_pos, int level_x,
                            int level_y, ABall *ball, double &reflection_pos );
  void Draw_Brick(HDC hdc, int x, int y, EBrick_Type brick_type);
  void Set_Brick_Letter_Colors(bool is_switch_color, HPEN &front_pen,
                               HBRUSH &front_brush, HPEN &back_pen,
                               HBRUSH &back_brush);
  void Draw_Brick_Letter(HDC hdc, int x, int y, EBrick_Type brick_type,
                         ELetter_Type letter_type, int rotation_step);

  bool Hit_Circle_On_Line(double y, double next_x_pos, double left_x,
                          double right_x, double radius, double &x);

  char Current_Level[AsConfig::LEVEL_HEIGHT][AsConfig::LEVEL_WIDTH];

 

  double Current_Brick_Left_X, Current_Brick_Right_X;
  double Current_Brick_Top_Y, Current_Brick_Low_Y;

  HPEN Brick_Red_Pen, Brick_Blue_Pen, Letter_Pen;
  HBRUSH Brick_Red_Brush, Brick_Blue_Brush;
  RECT Level_Rect;
};
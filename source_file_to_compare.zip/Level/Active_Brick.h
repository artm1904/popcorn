#pragma once

#include "../Config/Config.h"

#include <windef.h>

enum EBrick_Type { EBT_EMPTY, EBT_RED, EBT_BLUE };

class AActive_Brick {

public:
  AActive_Brick(EBrick_Type Brick_Type);

  void Act();

  void Draw(HDC hdc, RECT &paint_area);
  static void Setup_Colors();

private:
  static unsigned char Get_Fading_Chanel(unsigned char color,
                                         unsigned char bg_color, int step);
  static void Get_Fading_Color(const AColor &color, int step, HPEN &pen,
                               HBRUSH &brush);

  int Fade_Step;

  EBrick_Type Brick_Type;
  RECT Brick_Rect;

  static const int Max_Fade_Step = 80;
  static HPEN Fadding_Blue_Brick_Pens[Max_Fade_Step];
  static HPEN Fadding_Red_Brick_Pens[Max_Fade_Step];

  static HBRUSH Fadding_Blue_Brick_Brushes[Max_Fade_Step];
  static HBRUSH Fadding_Red_Brick_Brushes[Max_Fade_Step];
};
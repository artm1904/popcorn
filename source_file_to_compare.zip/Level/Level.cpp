#include "Level.h"
#include "Active_Brick.h"
#include <Windows.h>
#include <cmath>
#include <cstring>
#include <windef.h>

char ALevel::Level_01[AsConfig::LEVEL_HEIGHT][AsConfig::LEVEL_WIDTH] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 1
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, // 2
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, // 3
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, // 4
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, // 5
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, // 6
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, // 7
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, // 8
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, // 9
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 10
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 11
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 12
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 13
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0  // 14
};

char ALevel::Test_Level_01[AsConfig::LEVEL_HEIGHT][AsConfig::LEVEL_WIDTH] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 1
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, // 2
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 3
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 4
    0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, // 5
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 6
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 7
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 8
    0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, // 9
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 10
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 11
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 12
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, // 13
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0  // 14
};

// ALevel CLASS METHODS IMPLEMENTATION
// //////////////////////////////////////////////////////////////////////////////////////////////////

ALevel::ALevel()
    : Active_Brick(EBT_RED), Brick_Red_Pen(0), Brick_Blue_Pen(0), Letter_Pen(0),
      Brick_Red_Brush(0), Brick_Blue_Brush(0), Level_Rect{} {}

void ALevel::Init() {

  // Letter_Pen
  Letter_Pen = CreatePen(PS_SOLID, AsConfig::GLOBAL_SCALE, RGB(255, 255, 255));

  // BLUE BRICK
  AsConfig::Create_Pen_Brush(AsConfig::Blue_Brick_Color, Brick_Blue_Pen,
                             Brick_Blue_Brush);

  // RED BRICK
  AsConfig::Create_Pen_Brush(AsConfig::Red_Brick_Color, Brick_Red_Pen,
                             Brick_Red_Brush);

  Level_Rect.left = AsConfig::LEVEL_X_OFFSET * AsConfig::GLOBAL_SCALE;
  Level_Rect.top = AsConfig::LEVEL_Y_OFFSET * AsConfig::GLOBAL_SCALE;
  Level_Rect.right =
      (Level_Rect.left + AsConfig::LEVEL_WIDTH * AsConfig::CELL_WIDTH) *
      AsConfig::GLOBAL_SCALE;
  Level_Rect.bottom =
      (Level_Rect.top + AsConfig::LEVEL_HEIGHT * AsConfig::CELL_HEIGHT) *
      AsConfig::GLOBAL_SCALE;

  memset(Current_Level, 0, sizeof(Current_Level));
}

void ALevel::Ser_Current_Level(
    char level[AsConfig::LEVEL_HEIGHT][AsConfig::LEVEL_WIDTH]) {
  memcpy(Current_Level, level, sizeof(Current_Level));
}

void ALevel::Draw(HDC hdc, RECT &paint_area) {

  RECT intersection_rect;

  if (!IntersectRect(&intersection_rect, &paint_area, &Level_Rect)) {
    return;
  }

  for (int i = 0; i < AsConfig::LEVEL_HEIGHT; i++) {
    for (int j = 0; j < AsConfig::LEVEL_WIDTH; j++) {
      Draw_Brick(hdc, AsConfig::LEVEL_X_OFFSET + j * (AsConfig::CELL_WIDTH),
                 AsConfig::LEVEL_Y_OFFSET + i * AsConfig::CELL_HEIGHT,
                 (EBrick_Type)Current_Level[i][j]);
    }
  }

  // Active_Brick.Draw(hdc, paint_area);
}

void ALevel::Draw_Brick(HDC hdc, int x, int y, EBrick_Type brick_type) {

  HPEN pen;
  HBRUSH brush;

  switch (brick_type) {
  case EBT_EMPTY:
    return;
    break;
  case EBT_BLUE:
    pen = Brick_Blue_Pen;
    brush = Brick_Blue_Brush;
    break;
  case EBT_RED:
    pen = Brick_Red_Pen;
    brush = Brick_Red_Brush;
    break;

  default:
    return;
  }

  SelectObject(hdc, pen);
  SelectObject(hdc, brush);

  // Rectangle(hdc, x * GLOBAL_SCALE, y * GLOBAL_SCALE,
  //           (x + AsConfig::BRICK_WIDTH) * GLOBAL_SCALE,
  //           (y + AsConfig::BRICK_HEIGHT) * GLOBAL_SCALE);

  RoundRect(hdc, x * AsConfig::GLOBAL_SCALE, y * AsConfig::GLOBAL_SCALE,
            (x + AsConfig::BRICK_WIDTH) * AsConfig::GLOBAL_SCALE,
            (y + AsConfig::BRICK_HEIGHT) * AsConfig::GLOBAL_SCALE,
            2 * AsConfig::GLOBAL_SCALE, 2 * AsConfig::GLOBAL_SCALE);
}

void ALevel::Set_Brick_Letter_Colors(bool is_switch_color, HPEN &front_pen,
                                     HBRUSH &front_brush, HPEN &back_pen,
                                     HBRUSH &back_brush) {
  if (is_switch_color) {
    front_pen = Brick_Red_Pen;
    front_brush = Brick_Red_Brush;

    back_pen = Brick_Blue_Pen;
    back_brush = Brick_Blue_Brush;
  } else {
    front_pen = Brick_Blue_Pen;
    front_brush = Brick_Blue_Brush;

    back_pen = Brick_Red_Pen;
    back_brush = Brick_Red_Brush;
  }
}
void ALevel::Draw_Brick_Letter(HDC hdc, int x, int y, EBrick_Type brick_type,
                               ELetter_Type letter_type, int rotation_step) {

  bool is_switch_color;
  double offset;
  double rotation_angle; // 1 of 16 steps, step to degree

  int brick_half_height = AsConfig::BRICK_HEIGHT * AsConfig::GLOBAL_SCALE / 2;
  int back_part_offset;

  HPEN front_pen, back_pen;
  HBRUSH front_brush, back_brush;
  XFORM xform, old_xform;

  if (!(brick_type == EBT_RED || brick_type == EBT_BLUE)) {
    return;
  }

  // Get only 1- 16 rotation step
  rotation_step = rotation_step % 16;

  if (rotation_step < 8) {
    rotation_angle = 2.0 * M_PI / 16.0 * (double)rotation_step;
  } else {
    rotation_angle = 2.0 * M_PI / 16.0 * (double)(8 - rotation_step);
  }

  if (rotation_step > 4 && rotation_step <= 12) {

    if (brick_type == EBT_BLUE) {
      is_switch_color = true;
    } else {
      is_switch_color = false;
    }

  } else {

    if (brick_type == EBT_RED) {
      is_switch_color = true;
    } else {
      is_switch_color = false;
    }
  }
  Set_Brick_Letter_Colors(is_switch_color, front_pen, front_brush, back_pen,
                          back_brush);
  // Handle the case when the brick has zero width
  if (rotation_step == 4 || rotation_step == 12) {

    // Print back
    SelectObject(hdc, back_pen);
    SelectObject(hdc, back_brush);
    Rectangle(hdc, x, y + brick_half_height - AsConfig::GLOBAL_SCALE,
              x + AsConfig::BRICK_WIDTH * AsConfig::GLOBAL_SCALE,
              y + brick_half_height);

    // Print front
    SelectObject(hdc, front_pen);
    SelectObject(hdc, front_brush);
    Rectangle(hdc, x, y + brick_half_height,
              x + AsConfig::BRICK_WIDTH * AsConfig::GLOBAL_SCALE,
              y + brick_half_height + AsConfig::GLOBAL_SCALE - 1);
  } else {

    // Set graphics mode to advanced to enable world transformations
    SetGraphicsMode(hdc, GM_ADVANCED);

    // Define a transformation matrix for rotating and translating the brick
    xform.eM11 = 1.0f;                          // cos(30 degrees)
    xform.eM12 = 0.0f;                          // sin(30 degrees)
    xform.eM21 = 0.0f;                          // -sin(30 degrees)
    xform.eM22 = cos(rotation_angle);           // cos(30 degrees)
    xform.eDx = x;                              // translation in x
    xform.eDy = y + (float)(brick_half_height); // translation in y

    // Save the current world transformation
    GetWorldTransform(hdc, &old_xform);

    // Apply the new transformation
    SetWorldTransform(hdc, &xform);

    offset = 3.0 * (1.0 - abs(xform.eM22)) * (double)AsConfig::GLOBAL_SCALE;
    back_part_offset = round(offset);
    // Draw the back side of the brick
    SelectObject(hdc, back_pen);
    SelectObject(hdc, back_brush);
    Rectangle(hdc, 0, -brick_half_height - back_part_offset,
              AsConfig::BRICK_WIDTH * AsConfig::GLOBAL_SCALE,
              brick_half_height - back_part_offset);

    // Draw the brick with the new transformation
    SelectObject(hdc, front_pen);
    SelectObject(hdc, front_brush);

    Rectangle(hdc, 0, -brick_half_height,
              AsConfig::BRICK_WIDTH * AsConfig::GLOBAL_SCALE,
              brick_half_height);

    if (rotation_step > 4 && rotation_step <= 12) {

      if (letter_type == ELT_O) {
        SelectObject(hdc, Letter_Pen);
        Ellipse(hdc, 0 + 5 * AsConfig::GLOBAL_SCALE,
                (-5 * AsConfig::GLOBAL_SCALE) / 2,
                0 + 10 * AsConfig::GLOBAL_SCALE,
                (5 * AsConfig::GLOBAL_SCALE) / 2);
      }
    }
    // Restore the original world transformation
    SetWorldTransform(hdc, &old_xform);
  }
}

/**
 * @brief Checks if the ball hits any brick in the level.
 *
 * This function iterates through all bricks in the level and checks if the
 * ball's next position will result in a collision with any of them.
 *
 * @param next_x_pos The next x-position of the ball's center.
 * @param next_y_pos The next y-position of the ball's center.
 * @param ball Pointer to the ABall object representing the ball.
 * @return true If the ball hits a brick, false otherwise.
 */
bool ALevel::Check_Hit(double next_x_pos, double next_y_pos, ABall *ball) {

  double min_ball_x;
  double max_ball_x;
  double min_ball_y;
  double max_ball_y;

  int min_level_x;
  int max_level_x;
  int min_level_y;
  int max_level_y;

  bool got_vertical_hit, got_horizontal_hit;
  double vertical_reflection_pos, horizontal_reflection_pos;

  if (next_y_pos > AsConfig::LEVEL_Y_OFFSET +
                       (AsConfig::LEVEL_HEIGHT - 1) * AsConfig::CELL_HEIGHT +
                       AsConfig::BRICK_HEIGHT) {
    return false;
  }

  min_ball_x = next_x_pos - ball->RADIUS;
  max_ball_x = next_x_pos + ball->RADIUS;
  min_ball_y = next_y_pos - ball->RADIUS;
  max_ball_y = next_y_pos + ball->RADIUS;

  min_level_x = (int)(min_ball_x - AsConfig::LEVEL_X_OFFSET) /
                (double)AsConfig::CELL_WIDTH;
  max_level_x = (int)(max_ball_x - AsConfig::LEVEL_X_OFFSET) /
                (double)AsConfig::CELL_WIDTH;
  min_level_y = (int)(min_ball_y - AsConfig::LEVEL_Y_OFFSET) /
                (double)AsConfig::CELL_HEIGHT;
  max_level_y = (int)(max_ball_y - AsConfig::LEVEL_Y_OFFSET) /
                (double)AsConfig::CELL_HEIGHT;

  for (int i = max_level_y; i >= min_level_y; i--) {

    Current_Brick_Top_Y = AsConfig::LEVEL_Y_OFFSET + i * AsConfig::CELL_HEIGHT;

    Current_Brick_Low_Y = Current_Brick_Top_Y + AsConfig::BRICK_HEIGHT;

    for (int j = min_level_x; j < max_level_x; j++) {
      if (Current_Level[i][j] == 0) {
        continue;
      }

      // the brick interval to check the ball's position is hit the current
      // brick
      Current_Brick_Left_X =
          AsConfig::LEVEL_X_OFFSET + j * AsConfig::CELL_WIDTH;
      Current_Brick_Right_X = Current_Brick_Left_X + AsConfig::BRICK_WIDTH;

      got_vertical_hit = (Check_Vertical_Hit(next_x_pos, next_y_pos, j, i, ball,
                                             vertical_reflection_pos));

      got_horizontal_hit = (Check_Horizontal_Hit(
          next_x_pos, next_y_pos, j, i, ball, horizontal_reflection_pos));

      if (got_vertical_hit && got_horizontal_hit) {

        if (vertical_reflection_pos <= horizontal_reflection_pos) {
          ball->Reflect(true);
        } else {
          ball->Reflect(false);
        }
      }

      else if (got_vertical_hit) {
        ball->Reflect(true);
        return true;
      }

      else {
          ball->Reflect(false);
          return true;
        }

      // if (Is_Check_Horizontal_First(next_x_pos, next_y_pos)) {
      //   if (Check_Horizontal_Hit(next_x_pos, next_y_pos, j, i, ball)) {
      //     return true;
      //   }

      //   if (Check_Vertical_Hit(next_x_pos, next_y_pos, j, i, ball)) {
      //     return true;
      //   }
      // } else {

      //   if (Check_Vertical_Hit(next_x_pos, next_y_pos, j, i, ball)) {
      //     return true;
      //   }

      //   if (Check_Horizontal_Hit(next_x_pos, next_y_pos, j, i, ball)) {
      //     return true;
      //   }
      // }
    }
  }
  return false;
}

bool ALevel::Is_Check_Horizontal_First(double next_x_pos, double next_y_pos) {

  double min_distance_to_horizontal, min_distance_to_vertical;
  double another_min_distance_to_horizontal, another_min_distance_to_vertical;
  // This block of code checks if the ball hits the brick's horizontal line
  // of the brick and the vertical line of the brick
  min_distance_to_horizontal = fabs(next_x_pos - Current_Brick_Left_X);
  another_min_distance_to_horizontal = fabs(next_x_pos - Current_Brick_Right_X);

  if (another_min_distance_to_horizontal < min_distance_to_horizontal) {
    min_distance_to_horizontal = another_min_distance_to_horizontal;
  }

  min_distance_to_vertical = fabs(next_y_pos - Current_Brick_Top_Y);
  another_min_distance_to_vertical = fabs(next_y_pos - Current_Brick_Low_Y);

  if (another_min_distance_to_vertical < min_distance_to_vertical) {
    min_distance_to_vertical = another_min_distance_to_vertical;
  }
  //////////////////////////////////////////////////////

  if (min_distance_to_horizontal <= min_distance_to_vertical) {
    return true;
  } else {
    return false;
  }
}

bool ALevel::Check_Vertical_Hit(double next_x_pos, double next_y_pos,

                                int level_x, int level_y, ABall *ball,
                                double &reflection_pos) {

  double direction = ball->Get_Direction();

  // Check if the ball hits the brick's bottom vertical line of the brick
  if (direction > 0 && direction < M_PI) {
    if (Hit_Circle_On_Line(next_y_pos - Current_Brick_Low_Y, next_x_pos,
                           Current_Brick_Left_X, Current_Brick_Right_X,
                           ball->RADIUS, reflection_pos)) {

      if (level_y < AsConfig::LEVEL_HEIGHT - 1 &&
          Current_Level[level_y + 1][level_x] == 0) {

        // ball->Reflect(true);
        return true;
      } else {
        return false;
      }
    }
    return false;
  }

  // Check if the ball hits the brick's top vertical line of the brick
  if (direction >= M_PI && direction <= 2.0 * M_PI) {
    if (Hit_Circle_On_Line(next_y_pos - Current_Brick_Top_Y, next_x_pos,
                           Current_Brick_Left_X, Current_Brick_Right_X,
                           ball->RADIUS, reflection_pos)) {

      if (level_y > 0 && Current_Level[level_y - 1][level_x] == 0) {

        // ball->Reflect(true);
        return true;
      } else {
        return false;
      }
    }
    return false;
  }
}

bool ALevel::Check_Horizontal_Hit(double next_x_pos, double next_y_pos,

                                  int level_x, int level_y, ABall *ball,
                                  double &reflection_pos) {

  double direction = ball->Get_Direction();
  // Check if the ball hits the brick's left horizontal line of the brick
  if (direction >= 0 && direction < M_PI_2 ||
      direction >= M_PI + M_PI_2 && direction <= 2.0 * M_PI) {
    if (Hit_Circle_On_Line(Current_Brick_Left_X - next_x_pos, next_y_pos,
                           Current_Brick_Top_Y, Current_Brick_Low_Y,
                           ball->RADIUS, reflection_pos)) {

      if (level_x > 0 && Current_Level[level_y][level_x - 1] == 0) {

        // ball->Reflect(false);
        return true;
      } else {
        return false;
      }
    }
    return false;
  }

  // Check if the ball hits the brick's right horizontal line of the brick
  if (direction >= M_PI_2 && direction < M_PI_2 + M_PI) {
    if (Hit_Circle_On_Line(Current_Brick_Right_X - next_x_pos, next_y_pos,
                           Current_Brick_Top_Y, Current_Brick_Low_Y,
                           ball->RADIUS, reflection_pos)) {

      if (level_x < AsConfig::LEVEL_WIDTH &&
          Current_Level[level_y][level_x + 1] == 0) {

        // ball->Reflect(false);
        return true;
      } else {
        return false;
      }
    }
  }

  return false;
}

// Function to check if a ball hits a horizontal line of the brick
bool ALevel::Hit_Circle_On_Line(double y, double next_x_pos, double left_x,
                                double right_x, double radius, double &x) {

  double min_x, max_x;

  if (y > radius) {
    return false;
  }

  x = sqrt((radius * radius) - y * y);

  max_x = next_x_pos + x;
  min_x = next_x_pos - x;
  if (max_x >= left_x && max_x <= right_x ||
      min_x >= left_x && min_x <= right_x) {
    return true;
  } else {

    return false;
  }
}

// ALevel CLASS METHODS IMPLEMENTATION
// ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "../Ball/Ball.h"

#include <cmath>



class AsBorder : public AHit_Checker {

public:
  AsBorder()
      : Border_Blue_Pen(0), Border_White_Pen(0), Border_Blue_Brush(0),
        Border_White_Brush(0) {}

  bool Check_Hit(double next_x_pos, double next_y_pos,
                        ABall *ball) override;

  void Draw_Bounds(HDC hdc, RECT &paint_area);
  void Init();

private:
  void Draw_Element(HDC hdc, int x, int y, bool top_border);

  HPEN Border_Blue_Pen, Border_White_Pen;
  HBRUSH Border_Blue_Brush, Border_White_Brush;
};
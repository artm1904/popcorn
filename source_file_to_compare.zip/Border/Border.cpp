#include "Border.h"
#include <windef.h>

// AsBorder CLASS METHODS IMPLEMENTATION
// //////////////////////////////////////////////////////////////////////////////////////////////////

void AsBorder::Draw_Element(HDC hdc, int x, int y, bool top_border) {

  // Draw the blue border of the level
  SelectObject(hdc, Border_Blue_Pen);
  SelectObject(hdc, Border_Blue_Brush);

  if (top_border) {
    Rectangle(hdc, (x)*AsConfig::GLOBAL_SCALE, (y + 1) * AsConfig::GLOBAL_SCALE,
              (x + 4) * AsConfig::GLOBAL_SCALE,
              (y + 4) * AsConfig::GLOBAL_SCALE);

  } else {
    Rectangle(hdc, (x + 1) * AsConfig::GLOBAL_SCALE, (y)*AsConfig::GLOBAL_SCALE,
              (x + 4) * AsConfig::GLOBAL_SCALE,
              (y + 4) * AsConfig::GLOBAL_SCALE);
  }

  // Draw the white border of the level
  SelectObject(hdc, Border_White_Pen);
  SelectObject(hdc, Border_White_Brush);

  if (top_border) {
    Rectangle(hdc, (x)*AsConfig::GLOBAL_SCALE, (y)*AsConfig::GLOBAL_SCALE,
              (x + 4) * AsConfig::GLOBAL_SCALE,
              (y + 1) * AsConfig::GLOBAL_SCALE);
  } else {
    Rectangle(hdc, (x)*AsConfig::GLOBAL_SCALE, (y)*AsConfig::GLOBAL_SCALE,
              (x + 1) * AsConfig::GLOBAL_SCALE,
              (y + 3) * AsConfig::GLOBAL_SCALE);
  }
  // Draw the black point on border of the level
  SelectObject(hdc, AsConfig::BG_Pen);
  SelectObject(hdc, AsConfig::BG_Brush);

  if (top_border) {
    Rectangle(
        hdc, (x + 2) * AsConfig::GLOBAL_SCALE, (y + 2) * AsConfig::GLOBAL_SCALE,
        (x + 3) * AsConfig::GLOBAL_SCALE, (y + 3) * AsConfig::GLOBAL_SCALE);
  } else {
    Rectangle(
        hdc, (x + 2) * AsConfig::GLOBAL_SCALE, (y + 1) * AsConfig::GLOBAL_SCALE,
        (x + 3) * AsConfig::GLOBAL_SCALE, (y + 2) * AsConfig::GLOBAL_SCALE);
  }
}

// Draw the bounds of the level, left and right, top and bottom
void AsBorder::Draw_Bounds(HDC hdc, RECT &paint_area) {

  for (int i = 0; i < 50; i++) {
    Draw_Element(hdc, 2, 1 + i * 4, false);
  }

  for (int i = 0; i < 50; i++) {
    Draw_Element(hdc, 201, 1 + i * 4, false);
  }

  for (int i = 0; i < 50; i++) {
    Draw_Element(hdc, 3 + i * 4, 0, true);
  }
}

void AsBorder::Init() {

  // BLUE BORDER
  AsConfig::Create_Pen_Brush(85, 255, 255, Border_Blue_Pen, Border_Blue_Brush);

  // WHITE BORDER
  AsConfig::Create_Pen_Brush(255, 255, 255, Border_White_Pen,
                             Border_White_Brush);
}

bool AsBorder::Check_Hit(double next_x_pos, double next_y_pos, ABall *ball) {
  bool got_hit = false;

  // Check if Ball touch the left level border -> reverse x and direction
  if (next_x_pos - ball->RADIUS < AsConfig::Border_X_Offset) {
    got_hit = true;
    ball->Reflect(false);
  }

  // Check if Ball touch the top level border -> reverse y and direction
  if (next_y_pos - ball->RADIUS < AsConfig::Border_Y_Offset) {
    got_hit = true;
    ball->Reflect(true);
  }

  // Check if Ball touch the rigth level border -> reverse x and direction
  if (next_x_pos + ball->RADIUS > AsConfig::Max_X_Pos + 5) {
    got_hit = true;
    ball->Reflect(false);
  }

  // Check if Ball touch the bottom level border -> reverse x and direction
  if (next_y_pos + ball->RADIUS > AsConfig::Max_Y_Pos) {

    if (AsConfig::Level_Has_Floor) {
      got_hit = true;
      ball->Reflect(true);
    } else {

      // LOST
      if (next_y_pos + ball->RADIUS > AsConfig::Max_Y_Pos + ball->RADIUS * 4) {
        ball->Set_State(EBS_Lost, next_x_pos);
      }
    }
  }
  return got_hit;
}

// AsBorder CLASS METHODS IMPLEMENTATION
// //////////////////////////////////////////////////////////////////////////////////////////////////

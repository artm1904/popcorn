#include "Ball.h"

// ABall CLASS METHODS IMPLEMENTATION
// //////////////////////////////////////////////////////////////////////////////////////////////////

int ABall::HIT_CHECKER_COUNT = 0;
AHit_Checker *ABall::Hit_Checkers[] = {};

ABall::ABall()
    : Ball_State(EBS_Normal), Ball_Speed(), Ball_Direction(), Ball_Pen(0),
      Ball_Brush(0), Test_Iteration(0), Testing_Is_Active (false), Center_X_Pos(0),
      Center_Y_Pos(START_BALL_Y_POS), Rest_Distance(0.0), Ball_Rect{},
      Prev_Ball_Rect{} {
  
  //      Set_State(EBS_Normal, 0);
}

void ABall::Draw(HDC hdc, RECT &paint_area) {

  RECT intersection_rect;

  // Clean the last ball position
  if (IntersectRect(&intersection_rect, &paint_area, &Prev_Ball_Rect)) {

    SelectObject(hdc, AsConfig::BG_Pen);
    SelectObject(hdc, AsConfig::BG_Brush);

    Ellipse(hdc, Prev_Ball_Rect.left, Prev_Ball_Rect.top,
            Prev_Ball_Rect.right - 1, Prev_Ball_Rect.bottom - 1);
  }


  if (Ball_State== EBS_Lost){
    return;
  }
  // Draw the ball
  if (IntersectRect(&intersection_rect, &paint_area, &Ball_Rect)) {
    SelectObject(hdc, Ball_Pen);
    SelectObject(hdc, Ball_Brush);

    Ellipse(hdc, Ball_Rect.left, Ball_Rect.top, Ball_Rect.right - 1,
            Ball_Rect.bottom - 1);
  }
}

void ABall::Init() {

  // White Ball
  AsConfig::Create_Pen_Brush(255, 255, 255, Ball_Pen, Ball_Brush);
}

void ABall::Move() {

  bool got_hit = false;
  double next_x_pos, next_y_pos;

  double step_size = 1.0 / RADIUS;

  if (Ball_State != EBS_Normal) {
    return;
  }

  Prev_Ball_Rect = Ball_Rect;
  Rest_Distance += Ball_Speed;

  while (Rest_Distance >= step_size) {
    got_hit = false;

    next_x_pos = Center_X_Pos + step_size * cos(Ball_Direction);
    next_y_pos = Center_Y_Pos - step_size * sin(Ball_Direction);

    // Check if Ball touch one of the level borders [i=0]
    // Check if Ball touch the one of the bricks [i=1]
    // Check if Ball touch platform  [i=2]
    for (int i = 0; i < HIT_CHECKER_COUNT; ++i) {
      got_hit =
          got_hit | Hit_Checkers[i]->Check_Hit(next_x_pos, next_y_pos, this);
    }

    // The ball continues to move if it dont touch any of the level borders or
    // platform.
    if (!got_hit) {
      Rest_Distance -= step_size;
      Center_X_Pos = next_x_pos;
      Center_Y_Pos = next_y_pos;

      if (Testing_Is_Active) {
        Rest_Test_Distance -= step_size;
      }
    }

    Redraw_Ball();
  }
}

void ABall::Set_For_Test() {
  Testing_Is_Active = true;
  Rest_Test_Distance = 50;
  Set_State(EBS_Normal, 80 + Test_Iteration, 100);

  Center_Y_Pos = 100;

  ++Test_Iteration;
}

bool ABall::Is_Test_Finished() {

  if (Testing_Is_Active) {

    if (Rest_Test_Distance <= 0.0) {
      Testing_Is_Active = false;
      Set_State(EBS_Lost, 0);
      return true;
    }
  } 
    return false;
  
}

void ABall::Set_State(EBall_State new_state, int x_pos, double y_pos) {
  switch (new_state) {

  case EBS_Normal:
    Center_X_Pos = x_pos;
    Center_Y_Pos =y_pos;
    Rest_Distance = 0.0;
    Ball_Speed = 3.6;
    Ball_Direction = M_PI_4;
    Redraw_Ball();
    break;

  case EBS_Lost:
    Ball_Speed = 0.0;
    break;

  case EBS_On_Platform:
    Center_X_Pos = x_pos;
    Center_Y_Pos = y_pos;
    Rest_Distance = 0.0;
    Ball_Speed = 0.0;
    Ball_Direction = M_PI_4;
    Redraw_Ball();
    break;
  }

  Ball_State = new_state;
}

void ABall::Set_Direction(double new_direction) {

  while (new_direction > 2.0 * M_PI) {
    new_direction -= 2.0 * M_PI;
  }

  while (new_direction < 0.0) {
    new_direction += 2.0 * M_PI;
  }

  Ball_Direction = new_direction;
}

double ABall::Get_Direction() { return Ball_Direction; }

EBall_State ABall::Get_State() { return Ball_State; }

void ABall::Reflect(bool from_horizontal) {
  if (from_horizontal) {
    Set_Direction(-Ball_Direction);
  } else {
    Set_Direction(M_PI - Ball_Direction);
  }
}

void ABall::Add_Hit_Checkers(AHit_Checker *hit_checker) {

  if (HIT_CHECKER_COUNT >= sizeof(Hit_Checkers) / sizeof(Hit_Checkers[0])) {
    return;
  }

  // Add hit checker to the list. This list will be used to check if ball hit
  // any of
  Hit_Checkers[HIT_CHECKER_COUNT++] = hit_checker;
}

void ABall::Redraw_Ball() {
  Ball_Rect.left = (Center_X_Pos - RADIUS) * (AsConfig::GLOBAL_SCALE);
  Ball_Rect.top = (Center_Y_Pos - RADIUS) * AsConfig::GLOBAL_SCALE;
  Ball_Rect.right = Ball_Rect.left + (RADIUS * AsConfig::GLOBAL_SCALE);
  Ball_Rect.bottom = Ball_Rect.top + (RADIUS * AsConfig::GLOBAL_SCALE);

  InvalidateRect(AsConfig::Hwnd, &Prev_Ball_Rect, FALSE);
  InvalidateRect(AsConfig::Hwnd, &Ball_Rect, FALSE);
}

// ABall CLASS METHODS IMPLEMENTATION
// //////////////////////////////////////////////////////////////////////////////////////////////////
